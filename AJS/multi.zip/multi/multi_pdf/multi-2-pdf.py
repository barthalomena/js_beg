import PyPDF2 #import module
import os
import re

path = r'C:/meena/multi/cv'#folder path

with open ('multi-pdf.txt','a') as z: #writing
  for f in os.listdir(path):  #location to path
    pdfFileObj = open(f, 'rb') #its file variable and start
    pdfReader = PyPDF2.PdfFileReader(pdfFileObj) #reading
    print(pdfReader.numPages)  #return number of pages 
    
    for i in range(0,pdfReader.getNumPages()): #get that number of pages
      resume= pdfReader.getPage(i).extractText() #extrct the text
      print(resume) #print text as a resume
      c=resume.upper() 
      z.writelines(c) #write in a text file
  pdfFileObj.close() #close

print("================================================================================")




print("==================================================================================")
import re

# fileToRead = 'multi-pdf.txt'
# fileToWrite = 'emailExtracted.txt'

# delimiterInFile = [',', ';']
# def validateEmail(strEmail):
#     # .* Zero or more characters of any type. 
#     if re.match("(.*)@(.*).(.*)", strEmail):
#         return True
#     return False
# def writeFile(listData):
#     file = open(fileToWrite, 'w+')
#     strData = ""
#     for item in listData:
#         strData = strData+item+'\n'
#     file.write(strData)
# listEmail = []
# file = open(fileToRead, 'r') 
# listLine = file.readlines()
# for itemLine in listLine:
#     item =str(itemLine)
#     for delimeter in delimiterInFile:
#         item = item.replace(str(delimeter),' ')
    
#     wordList = item.split()
#     for word in wordList:
#         if(validateEmail(word)):
#             listEmail.append(word)
# if listEmail:
#     uniqEmail = set(listEmail)
#     print(len(uniqEmail),"emails collected!")
#     writeFile(uniqEmail)
# else:
#     print("No email found.")
print("==================================================================================")

with open('multi-pdf.txt', 'r') as f:
    for line in f:
        # look at line in loop
        print(line, end='')
print("successfully read")

# a=open('multi-pdf.txt','r+')
# read=a.read()
# print(read)
# a.close()
print("==================================================================================")


with open('resume.txt', 'w') as f: #creating
    #f.write(" 'PHONE_NUMBER':")
    #f.writelines("\n")
    phone = re.findall(r'[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]',line) #phone pattern
    print("Phone:",phone)  #print phone numbers
    f.writelines( phone) #
    f.writelines("\n")
# print("==================================================================================")
# with open('resume.txt', 'a') as f: #creating
#     #f.write("'EDUCATION':")
#     #f.writelines("\n")
#     Education =map(lambda x:x.upper(),[ 'B.E', 'B.E.', 'B.S', 'B.Sc', 'B.TECH',  'B. TECH', 'MSc Cyber Forensics', 'M.E',  'M.E.',  'M.S', "MSc", 'MCA',  'M.Sc', 'M.TECH',  'MTECH', "M. Tech", 'MSc Computer Science',  'MSc IT Security','MSc Networking Technology', 'MSc Software Engineering', 'MSc Hardware and Networking', "(CSE)", "CSE", 'Tally ERP Course' , 'BCA', 'B.Com in Computer Applications' , "computer science", "Bachelor of Computer Science", "MBA", 'Graphic Designing', '3D Animation & VFX', 'SSC', 'HSC', 'CBSE', 'ICSE', 'Bachelor of Technology', 'Mechanical Engineering' ])

#     edu=list(Education)
# #print(edu)
#     # print("'EDUCATION':")
#     # for Edu in op: 
#     #     if Edu in c:
#     #         #print(Edu)
#     #         f.writelines(Edu) #writing
#     #         f.writelines("\n")
#     dict={}
#     dict["Education"] = []
#     for name in edu:              
#         if name in c:
#             dict["Education"].append(name)
#             print(dict)
#     f.write(str(dict)) #writing    
#     f.writelines("\n")
# print("==================================================================================")
# with open('resume.txt', 'a') as f: #creating
#     #f.write("'SKILL':")
#     #f.writelines("\n")
#     skill= map(lambda x:x.upper(), ['Analytical ',' Linux ', 'Windows',' figma',' Java',' Python' ,' HTML',' CSS',' JavaScript',' JSF ','  Hibernate', ' JDBC',' Spring', ' Flask',  ' Apache Wicket', ' Oracle10g', ' Postgresql', ' MySql', ' WebLogic Server 12c',' SVN',' Git',' Jira ',' problem solving',' Microsoft', ' Java 8.0',' Java 11',' PHP',' Apache Tomcat ',' JDBC',' Servlet', ' JSP' ,' Spring', ' Spring MVC', ' RESTful webservices',' microservices',' Log4j' ,' Bitbucket',' GIT (Git-Hub, Bitbucket)', ' Jira', ' Trello',' GIT ',' Oracle',' RDBMS' ,' Amazon EC2',' ECS',' S3',' RDS',' ECR',' AWS IAM', ' Cloud Watch', ' Enterprise resource planning software',' Business leadership',' Verbal','  writing skills',' Data analytics',' Revenue recognition',' Risk  compliance',' Generally accepted accounting principles',' GAAP',' Data entry',' Attentive listening','  empathy',' Troubleshooting',' research','Patience',' Speed',' efficiency',' Positive attitude',' Diplomacy',' Communication skills',' Time management',' Business acumen','Data mining','Client relations',' Strategic thinking',' Verbal' ,' presentation skills',' Project management',' Collaboration',' Critical thinking',' Problem solving',' Content creation',' Market research',' Web analytics',' SEO ',' SEM',' Critical thinking',' Project management',' Content management systems',' Social media',' (strategy, campaigns, etc.)',' Creativity',' Coding languages',' Troubleshooting and testing skills',' Operating systems',' Database software',' UX and UI design',' Project management',' Web frameworks',' API design',' Teamwork',' Design principles', ' color theory ',' typography',' Brand development',' Storytelling',' Attention to detail',' Collaboration with clients',' Project management',' Commitment to deadlines',' Time management',' Verbal and presentation skills','Problem solving', ' Dependability ',' Java Technologies',' J2SE',' J2EE ',' Databases','  Oracle ',' Web/App ServerDisconnectedError',' Tomcat ','  Eclipse ','  STS ','  Operating Systems','  Windows family ','  Streaming Platform ','   Apache Kafka ','  Frameworks','  Spring','  Spring Boot','  Hibernate', '  RESTful Services' ,' Testing Tools', ' JMETER ',' Java',' Spring 5.0', ' Hibernate5.0',' Spring Boot',' REST Web Services','ApacheTomcat',' Maven'])

#     sk= list(skill)

#     #print("skills:")

#     # for skills in sk: 
#     #     if skills in c: 
#     #         #print(skill)
#     #         a=skills.split("delimiter")
#     #         #print(a)
            
#     #         f.write(str(a)) #writing
#     #         #f.writelines("\n") 
            
#     dict={}
#     dict["skills"] = []
#     for name in sk:              
#         if name in c:
#             dict["skills"].append(name)
#             print(dict)
#     f.write(str(dict)) #writing    
#     f.writelines("\n")

# print("==================================================================================")
# with open('resume.txt', 'a') as f: #creating
#     #f.write("EXPERIENCE:")
#     #f.writelines("\n")
#     Experience=map(lambda x:x.upper(),[' fresher','1 year','2 years','3 years','4 years','5 years','6 years','7 years','8 years','9 years','10 years','11 years','12 years','13 years','14 years','15 years','16 years','17 years','18 years','19 years','20 years','21 years','22 years'])
#     exp=list(Experience)
# #print(exp)
#     # print("'EXPERIENCE':")
#     # for expe in exp:
#     #     if expe in c:
#     #         #print(expe)
            
#     #         f.writelines(expe) #writing
#     #         f.writelines("\n")
#     # else:
#     #     if expe not in c:
#     #         #print("Not found")
#     #         f.writelines("Not Found")
#     #         f.writelines("\n") #writing
#     dict={}
#     dict["Experience"] = []
#     for name in exp:              
#         if name in c:
#             dict["Experience"].append(name)
#             print(dict)
#     f.write(str(dict)) #writing    
#     f.writelines("\n")
# print("==================================================================================")









# import glob, os
# os.chdir(r'C:/Users/Anto/Desktop/mena/resume/Java Resumes')
# for file in glob.glob("*.pdf"):
#     print(file)
# # import re

# fileToRead = 'multi-pdf.txt'
# fileToWrite = 'emailExtracted.txt'

# delimiterInFile = [',', ';']
# def validateEmail(strEmail):
#     # .* Zero or more characters of any type. 
#     if re.match("(.*)@(.*).(.*)", strEmail):
#         return True
#     return False
# def writeFile(listData):
#     file = open(fileToWrite, 'w+')
#     strData = ""
#     for item in listData:
#         strData = strData+item+'\n'
#     file.write(strData)
# listEmail = []
# file = open(fileToRead, 'r') 
# listLine = file.readlines()
# for itemLine in listLine:
#     item =str(itemLine)
#     for delimeter in delimiterInFile:
#         item = item.replace(str(delimeter),' ')
    
#     wordList = item.split()
#     for word in wordList:
#         if(validateEmail(word)):
#             listEmail.append(word)
# if listEmail:
#     uniqEmail = set(listEmail)
#     print(len(uniqEmail),"emails collected!")
#     writeFile(uniqEmail)
# else:
#     print("No email found.")