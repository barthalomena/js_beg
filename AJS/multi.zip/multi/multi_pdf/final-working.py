import PyPDF2 #import
import re
import json

fileObj = open('2.pdf', 'rb') #creating fill obj

pdfReader = PyPDF2.PdfFileReader(fileObj) #pdfreading

pageObj = pdfReader.getPage(0) #pages

resume = pageObj.extractText() #text extracting

print("Total Pages : {} ".format(pdfReader.numPages)) #total pages, get value from pageobj

print("==================================================================================")

#print(resume) #print text from pageobj
c=resume.upper()
# print(c)

print("==================================================================================")

print("length of pdf :",len(resume)) #lenth of resume letters

print("==================================================================================")
with open('resume.txt', 'a') as f: #creating
    #f.write(" 'EMAIL':")
    #f.writelines("\n")
    emails =re.findall(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", resume) #email pattern
    #print ("Mail:",emails) #print email
    f.writelines(emails) #writing
    f.writelines("\n")
print("==================================================================================")
with open('resume.txt', 'a') as f: #creating
    #f.write(" 'PHONE_NUMBER':")
    #f.writelines("\n")
    phone = re.findall(r'[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]', resume) #phone pattern
    #print("Phone:",phone)  #print phone numbers
    f.writelines( phone) #
    f.writelines("\n")
print("==================================================================================")
with open('resume.txt', 'a') as f: #creating
    #f.write("'EDUCATION':")
    #f.writelines("\n")
    Education =map(lambda x:x.upper(),[ 'B.E', 'B.E.', 'B.S', 'B.Sc', 'B.TECH',  'B. TECH', 'MSc Cyber Forensics', 'M.E',  'M.E.',  'M.S', "MSc", 'MCA',  'M.Sc', 'M.TECH',  'MTECH', "M. Tech", 'MSc Computer Science',  'MSc IT Security','MSc Networking Technology', 'MSc Software Engineering', 'MSc Hardware and Networking', "(CSE)", "CSE", 'Tally ERP Course' , 'BCA', 'B.Com in Computer Applications' , "computer science", "Bachelor of Computer Science", "MBA", 'Graphic Designing', '3D Animation & VFX', 'SSC', 'HSC', 'CBSE', 'ICSE', 'Bachelor of Technology', 'Mechanical Engineering' ])

    edu=list(Education)
#print(edu)
    # print("'EDUCATION':")
    # for Edu in op: 
    #     if Edu in c:
    #         #print(Edu)
    #         f.writelines(Edu) #writing
    #         f.writelines("\n")
    dict={}
    dict["Education"] = []
    for name in edu:              
        if name in c:
            dict["Education"].append(name)
            print(dict)
    f.write(str(dict)) #writing    
    f.writelines("\n")
print("==================================================================================")
with open('resume.txt', 'a') as f: #creating
    #f.write("'SKILL':")
    #f.writelines("\n")
    skill= map(lambda x:x.upper(), ['Analytical ',' Linux ', 'Windows',' figma',' Java',' Python' ,' HTML',' CSS',' JavaScript',' JSF ','  Hibernate', ' JDBC',' Spring', ' Flask',  ' Apache Wicket', ' Oracle10g', ' Postgresql', ' MySql', ' WebLogic Server 12c',' SVN',' Git',' Jira ',' problem solving',' Microsoft', ' Java 8.0',' Java 11',' PHP',' Apache Tomcat ',' JDBC',' Servlet', ' JSP' ,' Spring', ' Spring MVC', ' RESTful webservices',' microservices',' Log4j' ,' Bitbucket',' GIT (Git-Hub, Bitbucket)', ' Jira', ' Trello',' GIT ',' Oracle',' RDBMS' ,' Amazon EC2',' ECS',' S3',' RDS',' ECR',' AWS IAM', ' Cloud Watch', ' Enterprise resource planning software',' Business leadership',' Verbal','  writing skills',' Data analytics',' Revenue recognition',' Risk  compliance',' Generally accepted accounting principles',' GAAP',' Data entry',' Attentive listening','  empathy',' Troubleshooting',' research','Patience',' Speed',' efficiency',' Positive attitude',' Diplomacy',' Communication skills',' Time management',' Business acumen','Data mining','Client relations',' Strategic thinking',' Verbal' ,' presentation skills',' Project management',' Collaboration',' Critical thinking',' Problem solving',' Content creation',' Market research',' Web analytics',' SEO ',' SEM',' Critical thinking',' Project management',' Content management systems',' Social media',' (strategy, campaigns, etc.)',' Creativity',' Coding languages',' Troubleshooting and testing skills',' Operating systems',' Database software',' UX and UI design',' Project management',' Web frameworks',' API design',' Teamwork',' Design principles', ' color theory ',' typography',' Brand development',' Storytelling',' Attention to detail',' Collaboration with clients',' Project management',' Commitment to deadlines',' Time management',' Verbal and presentation skills','Problem solving', ' Dependability ',' Java Technologies',' J2SE',' J2EE ',' Databases','  Oracle ',' Web/App ServerDisconnectedError',' Tomcat ','  Eclipse ','  STS ','  Operating Systems','  Windows family ','  Streaming Platform ','   Apache Kafka ','  Frameworks','  Spring','  Spring Boot','  Hibernate', '  RESTful Services' ,' Testing Tools', ' JMETER ',' Java',' Spring 5.0', ' Hibernate5.0',' Spring Boot',' REST Web Services','ApacheTomcat',' Maven'])

    sk= list(skill)

    #print("skills:")

    # for skills in sk: 
    #     if skills in c: 
    #         #print(skill)
    #         a=skills.split("delimiter")
    #         #print(a)
            
    #         f.write(str(a)) #writing
    #         #f.writelines("\n") 
            
    dict={}
    dict["skills"] = []
    for name in sk:              
        if name in c:
            dict["skills"].append(name)
            print(dict)
    f.write(str(dict)) #writing    
    f.writelines("\n")

print("==================================================================================")
with open('resume.txt', 'a') as f: #creating
    #f.write("EXPERIENCE:")
    #f.writelines("\n")
    Experience=map(lambda x:x.upper(),[' fresher','1 year','2 years','3 years','4 years','5 years','6 years','7 years','8 years','9 years','10 years','11 years','12 years','13 years','14 years','15 years','16 years','17 years','18 years','19 years','20 years','21 years','22 years'])
    exp=list(Experience)
#print(exp)
    # print("'EXPERIENCE':")
    # for expe in exp:
    #     if expe in c:
    #         #print(expe)
            
    #         f.writelines(expe) #writing
    #         f.writelines("\n")
    # else:
    #     if expe not in c:
    #         #print("Not found")
    #         f.writelines("Not Found")
    #         f.writelines("\n") #writing
    dict={}
    dict["Experience"] = []
    for name in exp:              
        if name in c:
            dict["Experience"].append(name)
            print(dict)
    f.write(str(dict)) #writing    
    f.writelines("\n")
print("==================================================================================")




# kd=print('a: {}, b: {}, c: {},d:{}'.format(expe,phone,emails,skill))
# print(kd)
# print("==================================================================================")

# with open('resume.txt', 'a') as f: #creating
#     #f.writelines(c) #writing
#      f.writelines(emails) #writing
#      f.writelines("\n") #writing
     
#      f.writelines(skill)
#     # f.writelines(phone) #writing
#     # f.writelines(Edu) #writing
#     #f.writelines(skill) #writing
#     # f.writelines(expe) #writing

# y = json.dumps(skill) #convert to string
# print(y)
# # print("==================================================================================")
 
# # # # Convert string to Python dict
# z = json.loads(y) #convert to object
# print(z)
# # # print("==================================================================================")
  
# z=resume.txt
# with open('resume.json', 'w') as f: #converting to json file
#       json.dump(z, f)

# import json


# def read():
#     with open('resume.txt', 'r') as f:
#         return [l.strip() for l in f.readlines()]


# def batch(content, n=1):
#     length = len(content)
#     for num_idx in range(0, length, n):
#         yield content[num_idx:min(num_idx+n, length)]


# def emit(batched):
#     for n, name in enumerate([
#         'Email', 'Phone number', 'Education', 'Skills', 'Experience'
#     ]):
#         yield name, batched[n]

# content = read()
# batched = batch(content, 6)
# res = [dict(emit(b)) for b in batched]

# print(res)

# with open('output.json', 'w') as f:
#     f.write(json.dumps(res, indent=4))